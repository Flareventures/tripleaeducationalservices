// Minimal Supabase stub — replace with real client if using Supabase.
export const supabase = { from: ()=>({ insert: async()=>({}), select: async()=>({ data: [] }) }) } as any;
