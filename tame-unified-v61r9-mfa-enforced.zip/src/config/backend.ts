export type BackendKind = 'local' | 'firebase' | 'supabase';
export const ACTIVE_BACKEND: BackendKind = 'firebase';
