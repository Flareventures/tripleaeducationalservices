import React from 'react';
import { ScrollView, View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { resolveMfaSignIn } from '../../auth/mfa';
const theme = require('../../config/tameTheme').TameTheme;

export default function MFAVerify({ route, navigation }: any){
  const err = route.params?.resolverError;
  const [code, setCode] = React.useState('');

  const verify = async ()=>{
    try{
      const userCred = await resolveMfaSignIn(err, async ()=>({ factorId:'totp', code }));
      navigation.replace('HomeScreen');
    }catch(e:any){
      alert('MFA verification failed: ' + (e?.message||String(e)));
    }
  };

  return (<ScrollView contentContainerStyle={{padding:16, backgroundColor: theme.colors.surface}}>
    <Text style={[s.h,{color:theme.colors.primary}]}>Enter MFA Code</Text>
    <Text style={s.note}>Open your authenticator app and enter the 6‑digit code.</Text>
    <TextInput style={s.in} placeholder='123456' value={code} onChangeText={setCode} keyboardType='number-pad' />
    <Pressable style={[s.btn,{borderColor:theme.colors.primary}]} onPress={verify}><Text style={[s.bt,{color:theme.colors.primary}]}>Verify</Text></Pressable>
  </ScrollView>);
}
const s=StyleSheet.create({ h:{fontSize:22,fontWeight:'900'}, note:{opacity:0.75, marginTop:4}, in:{borderWidth:1,borderRadius:10,padding:10,marginTop:8,borderColor:'#CBD5E1',backgroundColor:'#fff'}, btn:{borderWidth:2,borderRadius:10,padding:10,marginTop:10,alignSelf:'flex-start'}, bt:{fontWeight:'900'} });
