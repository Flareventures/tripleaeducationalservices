import React from 'react';
import { ScrollView, Text } from 'react-native';
export default function DecodableReaderShortO(){
  return (<ScrollView contentContainerStyle={{padding:16}}><Text>Decodable — Short o (text)</Text></ScrollView>);
}
